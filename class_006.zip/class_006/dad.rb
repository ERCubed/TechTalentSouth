dad_says = "no"

# until dad_says == "yes"
# 	puts "Can we go to Itchy and Scratchy Land????"
# 	dad_says = gets.chomp
# end

# puts "OK FINE!"



while dad_says == "no"
	puts "Can we go to Itchy and Scratchy Land????"
	dad_says = gets.chomp
end

puts "OK FINE!"
	
require 'prime'

my_prime = Prime.first(10001)
puts my_prime
puts "the numer is #{my_prime.pop}"